package br.com.pizzaria.pizzaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
